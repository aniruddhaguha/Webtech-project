 <?php
    session_start();

  //initialized variable
    $id = 0;
    $Pname = "";
 	$Cname = "";
 	$price =  "";
 	$Expiredate = "";
 	$description = "";
 	$edit_state = false;

//connect to database
   $db = mysqli_connect('localhost','root', '', 'crud');

 // if publish button is clicked

 if (isset($_POST['publish']))  {

 	echo("$name");
 	$Pname = $_POST['name'];
 	$Cname = $_POST['company'];
 	$price = $_POST['price'];
 	$Expiredate = $_POST['date'];
 	$description = $_POST['description'];

 	$query = "INSERT INTO  product (Pname,Cname,price,date,description) VALUES ('$Pname','$Cname','$price','$date','$description')";
    mysqli_query($db, $query);
    $_SESSION['msg'] =  "product successfully added";

    header('location: index.php'); //redicted to index page after inserting


 }

 //update records
 
 if (isset($_POST['update'])) {
 	$Pname = mysql_real_escape_string($_POST['name']);
 	$Cname = mysql_real_escape_string($_POST['company']);
 	$price = mysql_real_escape_string($_POST['price']);
 	$description = mysql_real_escape_string($_POST['description']);
 	$id= mysql_real_escape_string($_POST['id']);
    $updatequery = "UPDATE product SET Pname='$Pname', Cname='$Cname', price='$price', description = '$description' WHERE id= $id";
 	mysqli_query($db, $updatequery);
    $_SESSION['msg'] =  "product successfully updated";
    header('location: index.php');
 }
 if (isset($_GET['del'])) {
    $id = $_GET['del'];
    mysqli_query($db, "DELETE FROM product WHERE id=$id");
    $_SESSION['msg'] =  "product successfully deleted";
 	header('location: index.php');
 }


  // retrive records
 $results =  mysqli_query($db, "SELECT * FROM product");





?> 
