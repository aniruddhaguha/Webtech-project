<?php include ('server.php'); 

  //fetch the record to be updated
  if (isset($_GET['edit'])) {
  	$id = $_GET['edit'];
  	$edit_state = true;

  	$rec = mysqli_query($db, "SELECT * FROM product WHERE id=$id");
  	$record = mysqli_fetch_array($rec);
  	$Pname = $record['Pname'];
  	$Cname = $record['Cname'];
  	$price = $record['price'];
  	$description= $record['description'];
  	$id = $record['id'];

  }


?>
<!DOCTYPE html>
<html>
<head>
	<title> CRUD Operation </title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
</body>
	<?php if (isset($_SESSION['msg'])) : ?>
		<div class="msg">
			<?php 
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
                
			?>
		</div>
	<?php  endif  ?>

	<table>
		<thead>
			<tr>
				<th> Product Name</th>
				<th> Company Name</th>
				<th> Price </th>
				<th> Expire Date </th>
				<th> Description </th>
				<th colspan="2"> Action </th>
			</tr>
		</thead>
		<tbody>
			<?php while ($row = mysqli_fetch_array ($results)) { ?>
				<tr>
					<td> <?php echo $row['Pname'];?> </td>
					<td> <?php echo $row['Cname'];?> </td>
					<td> <?php echo $row['price'];?> </td>
					<td> <input type="date" name=""> </td>
					<td> <?php echo $row['description'];?> </td>
					<td>
						<a class="edit_btn" href="index.php?edit=<?php echo $row['id']; ?>">Edit</a>
					</td>
					<td>
						<a class="del_btn" href="server.php?del=<?php echo $row['id']; ?>">Delete</a>
					</td>
			    </tr>
				<?php	} ?>
			
		</tbody>
	</table>
    
	    <form method="post" action="server.php">

		        <input type="hidden" name="id"  value="<?php echo $id; ?>">
		    	<div class="input-group">
		    		<label> Product Name </label>
		    		<input type="text" name="name" value="<?php echo $Pname; ?>">	
		    	</div>
		    	<div class="input-group">
		    		<label> Company Name </label>
		    		<input type="text" name="company" value="<?php echo $Cname; ?>">	
		    	</div>
		    	<div class="input-group">
		    		<label> Price </label>
		    		<input type="number" name="price" value="<?php echo $price; ?>">	
		    	</div>
		    	<div class="input-group">
	    			<label> Expire date </label>
	    			<input type="date" name="" value="<?php echo $date; ?>" >	
	    	    </div>
	    	    <div class="input-group">
	    			<label> Description </label>
	    			<input type="text" name="description" value="<?php echo $description; ?>" >	
	    	    </div>

	    	    <div class="input-group">
	    	    	<?php if ($edit_state == false):?>
	    	    		<button type="submit" name="publish" class="btn"> Publish </button>
	    	    	<?php else: ?>
	    	    	     <button type="submit" name="update" class="btn"> Update </button>
	    	    	<?php endif ?>
	      
	                	
    	        </div>

	    </form>  
</body>
</html> 