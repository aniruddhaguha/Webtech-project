-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2018 at 10:21 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `Pname` varchar(50) NOT NULL,
  `Cname` varchar(50) NOT NULL,
  `price` int(50) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `Pname`, `Cname`, `price`, `date`, `description`) VALUES
(3, 'Jeans', 'Denim', 1000, '0000-00-00', 'soft,stretch & long lasting.'),
(5, 'Samsung Grand Prime', 'Samsung', 13000, '0000-00-00', 'easy for using, no hanging, 4G supported'),
(6, 'Water bottle', 'Pran-RFL', 100, '0000-00-00', 'long lasting'),
(7, 'Jacket(hoodie)', 'EASY', 990, '0000-00-00', 'soft,100% cotton & long lasting.'),
(11, 'Pressure Cooker', 'Hawkings', 3000, '0000-00-00', 'long lasting(about 5-6 years for using)'),
(13, 'Facewash', 'garnier', 250, '0000-00-00', 'remove pimple from face, suitable for all ages people'),
(14, 'Television', 'Samsung', 29000, '0000-00-00', 'HD picture quality, 5 years warranty'),
(15, 'Fridge', 'LG-Butterfly', 25000, '0000-00-00', 'Non frost, savings electricity'),
(16, 'Xaomi Note 5 pro', 'Xaomi', 11800, '0000-00-00', 'easy for using, no hanging, 4G supported,'),
(17, 'Blanket', 'Home-Text', 3000, '0000-00-00', 'soft,100% cotton & long lasting.'),
(18, 'Shorts', 'Addidas', 400, '0000-00-00', 'soft,stretch & long lasting.'),
(21, 'Shirt', 'Denim', 500, '0000-00-00', 'soft & long lasting.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
