<?php

if (isset($_POST['submit'])) {
	$mail = $_POST['delmail'];

	if ($mail != "") {
		# code...
	$conn = mysqli_connect('localhost', 'root', '', 'webtech');
			
	$sql1 = "DELETE FROM teacher WHERE Email='".$mail."'";
	$sql2 =  "DELETE FROM student WHERE Email='".$mail."'";

$result = mysqli_query($conn, $sql1);
$result2 = mysqli_query($conn, $sql2);

echo "<center><h1>Your Account Deleted Successfully</h1><br><br><a href='Page_one.html'>Go Back</a></center>";
}
else{
	echo "<center><h1>No matching Email / Null found</h1><br><br><a href='settings.php'>Go Back</a></center>";
}
}
?>