<!DOCTYPE html>
<html>
<head>
	<title>Settings - ExamPortal</title>
		<style>
	.button {
	  background-color: #617CA4;
	  border: none;
	  color: white;
	  padding: 15px 32px;
	  text-align: center;
	  text-decoration: none;
	  
	  font-size: 16px;
	  margin: 4px 2px;
	  cursor: pointer;
	}
	.delete {
	  background-color: red;
	  border: none;
	  color: white;
	  padding: 15px 32px;
	  text-align: center;
	  text-decoration: none;
	  
	  font-size: 16px;
	  margin: 4px 2px;
	  cursor: pointer;
	}
	</style>
</head>
<body>
<center>
		<table border="3" class="menu" width="40%"><tr><td><h2><center>SETTINGS</center></h2></td></tr>
		<tr><td><b><center>EXAM PORTAL</center></b></td></tr>
		<tr>
			<td><center><a href="Page_one.html">Log Out</a></center></td>
		</tr>
		</table>
		<br><br>

<div>
	<input type="button" name="changepassword" value="Change Password" class="button" onclick="changePassword()">
</div>
<div>
	<input type="button" name="deleteuser" value="Delete User" class="delete" onclick="deleteUser()">
</div>
<br><br>
<div id="div2"></div>

</center>

<script type="text/javascript">
	function changePassword() {
	var field = document.getElementById('div2');

	field.innerHTML = "<form method='post' action='changepass.php'><div>Current Password : </div><input type='text' name='password' value=''><br><br><div>New Password : </div><input type='text' name='newPassword' value=''><br><br><input type='Submit' name='submit' value='Submit'></form>";		
	
	}
function deleteUser() {
	var field = document.getElementById('div2');

	field.innerHTML = "<form method='post' action='deleteUser.php'><div>Your Email Please : </div><input type='email' name='delmail' value=''><br><br><input type='Submit' name='submit' value='Submit'></form>";		
	
	}
</script>

</body>
</html>