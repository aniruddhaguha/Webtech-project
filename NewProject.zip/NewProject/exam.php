<!DOCTYPE html>
<html>
<head>
	<title>Exam - Exam Portal</title>
	<style>
	.button {
	  background-color: #617CA4;
	  border: none;
	  color: white;
	  padding: 5px 32px;
	  text-align: center;
	  text-decoration: none;
	  
	  font-size: 16px;
	  margin: 4px 2px;
	  cursor: pointer;
	}
	</style>
</head>
<body>
<form method="post" action="examCheck.php">
	<center>
		<div>
			<fieldset>
			<h1><b><legend>GOOD LUCK WITH YOUR EXAM ! Time running..!</legend</b></h1>
			<table><tr><td><font color="red">Time: <td><div id="time"></div></td></td></tr></table>
			
			<script type="text/javascript">
				var timeLeft = 1000;
				var space = document.getElementById('time');

				var timerId = setInterval(countdown, 1000);

				function countdown() {
				  if (timeLeft == 0) {
				  	window.alert("Exam Time FInished");
				    clearTimeout(timerId);
				    location.replace("student.html");
				  } 
				  else {
				    space.innerHTML = "<font color='red'>" + timeLeft + ' seconds remaining</font>';
				    timeLeft--;
				  }
				}	
			</script>

			</fieldset>
		</div>
		<div>
		<fieldset>
		<table>
		<tr>
		<td>
				<?php
					$conn = mysqli_connect('localhost', 'root', '', 'webtech');

					$sql = "Select * from question";

					$result = mysqli_query($conn, $sql);
		
					//echo "ul";
					while ($row=mysqli_fetch_assoc($result)) {
						$random = rand(1,3);
						if($random == 1){
							echo ($row['ID'].") Question: ".$row['question']."<br><input type='radio' name='".$row['ID']."'  value='0'>".$row['option1']." 
																			<input type='radio' name='".$row['ID']."'  value='0'>".$row['option2']."
																			<input type='radio' name='".$row['ID']."'  value='1'>".$row['answer']."<br><br>");
						}
						
						elseif($random == 2){
							echo ($row['ID'].") Question: ".$row['question']."<br><input type='radio' name='".$row['ID']."' value='0'>".$row['option2']." 
																			<input type='radio' name='".$row['ID']."' value='1'>".$row['answer']."
																			<input type='radio' name='".$row['ID']."' value='0'>".$row['option1']."<br><br>");
						}
						else{
							echo ($row['ID'].") Question: ".$row['question']."<br><input type='radio' name='".$row['ID']."' value='1'>".$row['answer']." 
																			<input type='radio' name='".$row['ID']."' value='0'>".$row['option2']."
																			<input type='radio' name='".$row['ID']."' value='0'>".$row['option1']."<br><br>");
						}


					}

					// while ($row['ID'].length!=0) {
						
					// // }

					//echo "<br><br><br>Total question = ".mysqli_num_rows($result);
					// for ($i=0; $i < $row; $i++) { 

					// 	# code...
					// }
					mysqli_close($conn);

					
		?>
		</td>
		</tr>
		<tr>
		<tr>
		</tr></tr>
		<tr><td colspan="3" align="right"><input type="submit" name="submit" class="button" value="Submit"></td></tr>
		</table>
	</fieldset>
	</div>
	</center>
</form>

</body>
</html>