<!DOCTYPE html>
<html>
<head>
	<title>Set Question</title>
	<style>
	.button {
	  background-color: #617CA4;
	  border: none;
	  color: white;
	  padding: 15px 32px;
	  text-align: center;
	  text-decoration: none;
	  
	  font-size: 16px;
	  margin: 4px 2px;
	  cursor: pointer;
	}

	.backbutton {
	  background-color: red;
	  border: none;
	  color: white;
	  padding: 15px 32px;
	  text-align: center;
	  text-decoration: none;
	  
	  font-size: 16px;
	  margin: 4px 2px;
	  cursor: pointer;
	}
	</style>
</head>
<body>

	<center>
		<form method="post">
			<fieldset>
			<table border="3" width="40%"><tr><td><h2><center>TEACHER</center></h2></td></tr>
			<tr><td><b><center>EXAM PORTAL  -  SET QUESTION</center></b></td></tr>
			<tr>
			<td><center><a href="Page_one.html">Log Out</a></center></td>
			</tr>
			

			</table>
			<br><br>
			<table>
			<tr><td><b>Question</b> :</td><td width="80%"> <input type="text" name="question" style="width: 100%"></td></tr>
			<tr><td><b>Correct Answer</b> :</td><td width="80%"> <input type="text" name="answer" style="width: 100%"></td></tr>
			<tr><td><b>Option 1</b> :</td><td width="80%"> <input type="text" name="option1" style="width: 100%"></td></tr>
			<tr><td><b>Option 2</b> :</td><td width="80%"> <input type="text" name="option2" style="width: 100%"></td></tr>
			<tr><td></td><td><br><input type="submit" name="submit" value="Add Question" class="button">
								<a href="teacher.php"><input type="button" name="Back" value="Back" class="backbutton"></a> </td></tr>
			</table>
			<br><br>
			</fieldset>
		</form>
	</center>

</body>
</html>

<?php
if (isset($_REQUEST['submit'])) {
	
	$question = $_REQUEST['question'];
	$answer = $_REQUEST['answer'];
	$option1 = $_REQUEST['option1'];
	$option2 = $_REQUEST['option2'];

	if(empty($question)==true || empty($answer)==true){
	}
	else{
		$conn = mysqli_connect('localhost', 'root', '', 'webtech');

		
		$sql = "INSERT INTO question values('','".$question."','".$answer."','".$option1."','".$option2."')";
		
		if(mysqli_query($conn, $sql)){
					echo "<br><br><br><br><center><b>Question and Answer Added Successfully</b></center>";
				}else{
					echo "failed";
				}

			
	}
}


?>