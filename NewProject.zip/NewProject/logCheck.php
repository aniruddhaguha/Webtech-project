<?php

	if(isset($_POST['submit'])){

		$mail 		= trim($_REQUEST['email']);
		$password 	= trim($_REQUEST['password']);
		$usertype = trim($_REQUEST['type']);

		if($mail == "" || $password == ""){
			
			header('location: login.php?error=null_found');

		}
		else{

			
			$conn = mysqli_connect('localhost', 'root', '', 'webtech');

			if($usertype=="student"){
			
			$sql = "select * from student where Email='".$mail."' and Password='".$password."'";

			$result = mysqli_query($conn, $sql);

			$row = mysqli_fetch_assoc($result);



			if($mail == $row['Email'] && $password == $row['Password']){
				
			
				header('location: student.html');


			}
			}
			else{
				$sql = "select * from teacher where Email='".$mail."' and Password='".$password."'"
				;

			$result = mysqli_query($conn, $sql);

			$row = mysqli_fetch_assoc($result);

			mysqli_close($conn);


			if($mail == $row['Email'] && $password == $row['Password']){
				


				header('location: teacher.php');
				
			}	


			}
			
		


}
}


?>