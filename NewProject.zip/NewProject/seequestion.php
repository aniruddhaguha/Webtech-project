<!DOCTYPE html>
<html>
<head>
	<title>See Question</title>
</head>
<body>
<center>
	
	<form method="post">
		
		<table border="3" width="40%"><tr><td><h2><center>TEACHER</center></h2></td></tr>
		<tr><td><b><center>EXAM PORTAL - SEE QUESTION</center></b></td></tr>
		<tr>
			<td><center><a href="Page_one.html">Log Out</a></center></td>
		</tr>
		</table>
		<br><br>
	</form>
	<fieldset>
		<table>
			<tr>
		<td>
		<?php
		$conn = mysqli_connect('localhost', 'root', '', 'webtech');

		$sql = "Select * from question";

		$result = mysqli_query($conn, $sql);
	

		while ($row=mysqli_fetch_assoc($result)) {
			print("<br><b>".$row['ID'].". Question :</b>".$row['question']."<br><b>Answer :</b>".$row['answer']."<br>");
		}
		mysqli_close($conn);
		?>
		</td>
		</tr>
		</table>
	</fieldset>

</center>

</body>
</html>

