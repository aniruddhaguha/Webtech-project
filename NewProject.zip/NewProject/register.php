<!DOCTYPE html>
<html>
<head>
	<title>Registration-ExamPortal.com</title>
</head>
<body>
<center><table border="2" width="40%"><tr><td><center><h1>Welcome to Registration</h1></center></td></tr></table></center>
<br><br>
<center>Please Fill all the Fields and must choose <b><u>USER TYPE.</u></b><br> <b><i>* MARKED FIELDS ARE MANDATORY.</i></b></center>
<br><br>


	<form method="post" action="registrationCheck.php">
	
	<center><table border="1" width="40%">
	
	<tr>
		<td width="50%">
			Name : <td width="50%"><input type="text" name="Name" value=" " size="45%">*</td>
		</td>
	</tr>

	<tr>
		<td width="50%">
			Date of Birth : <td><input type="date" name="DOB" value=" "> <i>dd/mm/yyyy</i></td>
		</td>
	</tr>

	<tr>
		<td width="50%">
			Email : <td width="50%"><input type="email" name="email" value="" size="45%">*</td>
		</td>
	</tr>
	
	<tr>
		<td width="50%">
			Password : <td><input type="password" name="Password" value="" size="45%">*</td>
		</td>
	</tr>
	

	<tr>
		<td width="50%">
			Confirm Password : <td><input type="password" name="CPassword" value="" size="45%">*</td>
		</td>
	</tr>
	
	<tr>
		<td width="50%">
			User Type : <td><select name="type" style="width: 50%">
				<option value="student">Student</option>
				<option value="teacher">Teacher</option>
			</select>*</td>
		</td>
	</tr>

	<tr>
	<td colspan="2"><br><center><input type="Submit" name="submit" value="Register"> <a href="Page_one.html"><input type="button" name="Back" value="Back"></a></center><br></td>
	</tr>
	
	</form>
</table></center>
</body>
</html>
