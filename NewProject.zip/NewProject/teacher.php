<!DOCTYPE html>
<html>
<head>
	<title>Teacher - Exam Portal</title>
	
</head>
<body>
	<center>

		<table border="3" width="40%"><tr><td><h2><center>TEACHER</center></h2></td></tr>
		<tr><td><b><center>EXAM PORTAL</center></b></td></tr>
		<tr>
			<td><center><a href="Page_one.html">Log Out</a></center></td>
		</tr>
		</table>
		<br><br>
		<table border="1" width="80%">
			
			<tr>
				<td>
					<center><h2><a href="setquestion.php">Set Question</a></h2></center>
				</td>
			</tr>

			<tr>
				<td>
					<center><h2><a href="seequestion.php">See Question</a></h2></center>
				</td>
			</tr>
			<tr>
				<td>
					<center><h2><a href="settings.php">Settings</a></h2></center>
				</td>
			</tr>

		</table>
	</center>	
</body>
</html>