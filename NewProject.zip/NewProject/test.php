<!DOCTYPE html>
<html>
<head>
	<title>test</title>
</head>
<body>
<form>
<input type="radio" name="answer[1]" value='0'>
<input type="radio" name="answer[1]" value='0'>
<input type="radio" name="answer[1]" value='1'>

<input type="submit" name="submit" value='submit'>
</form>
</body>
</html>
<?php
if (isset($_GET['submit'])) {
	if ($_GET['answer[1]']==1) {
		echo "joss";
	};
}
?>