<?php
	
	if (isset($_REQUEST['submit'])) {
		
		$name = $_REQUEST['Name'];
		$dob = $_REQUEST['DOB'];
		$email = $_REQUEST['email'];
		$pass = $_REQUEST['Password'];
		$cpass = $_REQUEST['CPassword'];
		$usertype = $_REQUEST['type'];
		
		

		if(empty($name) == true || empty($pass) == true || empty($email) || empty($usertype)){
			print ("<center>Incomplete Submission please recheck and try again.</center><br>
					<center><a href=register.php><b><h1>Go Back</h1></b></a></center>");

		}

		else{
			if($pass==$cpass)
			{
			$conn = mysqli_connect('localhost', 'root', '', 'webtech');

			if($usertype=="student"){
			$sql = "INSERT INTO student values('".$name."','".$email."','".$dob."','".$pass."','".$usertype."')";

			if(mysqli_query($conn, $sql)){
					echo "<center><h1>Registration Successfull</h1></center><br><a href=Page_one.html><center>Go Back</center></a>";
				}else{
					echo "failed";
				}

				mysqli_close($conn);
			}
			else{
						$sql = "INSERT INTO teacher values('".$name."','".$email."','".$dob."','".$pass."','".$usertype."')";

			if(mysqli_query($conn, $sql)){
					echo "<center><h1>Registration Successfull</h1></center><br><a href=Page_one.html><center>Go Back</center></a>";
				}else{
					echo "failed";
				}

				mysqli_close($conn);	
			}
		

		}
		else{
			echo "<center><h1>Password Did not Matched</h1></center><br><a href=register.php><center>Go Back</center></a>";
		}
	}

}		
			else{
				header('location:register.php');
			}	

?>