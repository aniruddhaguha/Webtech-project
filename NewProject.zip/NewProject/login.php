<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
<center>
	<form method="post" action="logCheck.php">
		<fieldset>
			<legend><h1>LOGIN to EXAM PORTAL</h1></legend><br><br>
			<table>
				<tr>
					<td>EMAIL</td>
					<td><input type="email" name="email"></td>
				</tr>
				<tr>
					<td>PASSWORD</td>
					<td><input type="password" name="password"></td>
				</tr>

				<tr>
				

				<td>User Type :</td> 
				<td><select name="type" style="width: 50%">
						<option value="student">Student</option>
						<option value="teacher">Teacher</option>
				</select>
				</td>
				
				</tr>
				
				<tr>
					<td></td>
					<td><br><input type="submit" name="submit" value="Login"></td>
				</tr>
			</table>
			<br><br>
		</fieldset>
	</form>
</center>
</body>
</html>