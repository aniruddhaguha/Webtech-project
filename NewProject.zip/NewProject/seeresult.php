<!DOCTYPE html>
<html>
<head>
	<title>See Question</title>
</head>
<body>
<center>
	
	<form method="post">
		
		<table border="3" width="40%"><tr><td><h2><center>STUDENT</center></h2></td></tr>
		<tr><td><b><center>EXAM PORTAL - SEE RESULT</center></b></td></tr>
		<tr>
			<td><center><a href="Page_one.html">Log Out</a></center></td>
		</tr>
		</table>
		<br><br>
	</form>
	<fieldset>
		<table>
			<tr>
		<td>
		<?php
		$conn = mysqli_connect('localhost', 'root', '', 'webtech');

		$sql = "Select * from result";

		$result = mysqli_query($conn, $sql);
	

		while ($row=mysqli_fetch_assoc($result)) {
			print("<br><b><font color='red'>EXAM NO. = ".$row['ID'].".</font><br> YOU GOT :</b>".$row['Mark']);
		}
		mysqli_close($conn);
		?>

		</td>
		</tr>
		<tr>
			<td align="right">
			<br><br><br>
				<a href="student.html">Go Back</a>
			</td>
		</tr>
		</table>
	</fieldset>

</center>

</body>
</html>

