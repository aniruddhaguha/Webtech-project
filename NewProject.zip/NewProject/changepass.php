<?php
if (isset($_POST['submit'])) {
	
$current = trim($_REQUEST['password']);
$new = trim($_REQUEST['newPassword']);

if ($current=="" || $new =="") {
	echo "Null Found";
}
else{
	//echo $current;
	//echo $new;
	$conn = mysqli_connect('localhost', 'root', '', 'webtech');
			
	$sql = "select * from teacher where Password='".$current."'";

		$result = mysqli_query($conn, $sql);

		$row = mysqli_fetch_assoc($result);

		if($current = $row['Password']){
			$update = "UPDATE `teacher` SET `Password`='".$new."' WHERE `Password`='".$current."'";
			mysqli_query($conn, $update);
			
			
			echo "<center><h1>Password changed successfully</h1></center><a href=teacher.php><center>Go Back</center></a>";
			
			mysqli_close($conn);
			// sleep(3);
			// header('location:teacher.php');
		}


}
}
?>