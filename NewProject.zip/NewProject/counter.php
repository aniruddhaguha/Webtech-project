<!DOCTYPE html>
<html>
<head>
	<title>nunu</title>
</head>
<body>
	<div id="some_div">
		
	</div>
<script type="text/javascript">
	var timeLeft = 30;
var elem = document.getElementById('some_div');

var timerId = setInterval(countdown, 1000);

function countdown() {
  if (timeLeft == 0) {
    clearTimeout(timerId);
    doSomething();
  } else {
    elem.innerHTML = timeLeft + ' seconds remaining';
    timeLeft--;
  }
}
</script>
</body>
</html>