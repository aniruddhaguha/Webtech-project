<?php
	if(isset($_POST['submit'])){

					$conn = mysqli_connect('localhost', 'root', '', 'webtech');

					$sql = "Select * from question";
					//$sql2 = "Select * from exam";

					$mark = 0;
					$wrong = 0;
					// $exno = 0;
					//$topic = "Math";//change hbe

					$result = mysqli_query($conn, $sql);
					//$result2 = mysqli_query($conn, $sql2);
					
						
					$row_cnt = mysqli_num_rows($result);
					//$exno = mysqli_num_rows($result2);


					for ($i=1; $i<=$row_cnt; $i++) { 
						if($_REQUEST[$i]==true){
							$mark = $mark+5;
						}
						else{
							$wrong = $wrong+5;
						}

					}

					$total = $mark+$wrong;
					$insertMark = "INSERT INTO result values('','".$mark."')";

					mysqli_query($conn,$insertMark);
					echo ("<center><h1>You Got <font color='green'>".$mark."</font> out of <font color='red'>".$total."</font></h1></center>");
					mysqli_close($conn);
				}
?>